import React, { useState } from 'react';
import { ExternalLink, Sparkles, X, Flame, ShieldCheck } from 'lucide-react';
import { sponsorAds } from '../data/mockCommunityData';

export default function AdBanner({ type = 'banner', adIndex = 0 }) {
  const [closed, setClosed] = useState(false);
  const ad = sponsorAds[adIndex % sponsorAds.length];

  if (closed || !ad) return null;

  if (type === 'native') {
    return (
      <div className="my-8 rounded-3xl overflow-hidden bg-gradient-to-r from-[#210c2e] via-[#2d113c] to-[#150a20] border border-rose-500/30 shadow-xl p-5 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-6 relative">
        <span className="absolute top-3 left-4 text-[9px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
          {ad.tag}
        </span>

        <div className="flex items-center gap-4 mt-4 md:mt-0">
          <img
            src={ad.image}
            alt={ad.title}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border border-rose-500/40 shrink-0"
          />
          <div>
            <h4 className="text-base sm:text-lg font-bold font-serif text-white">{ad.title}</h4>
            <p className="text-xs sm:text-sm text-rose-100/70 mt-1 max-w-xl font-serif leading-relaxed">
              {ad.subtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href={ad.link}
            onClick={(e) => {
              e.preventDefault();
              alert(`Navigating to sponsor: ${ad.title}`);
            }}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 text-white font-semibold text-xs sm:text-sm shadow-lg flex items-center gap-1.5 transition-all"
          >
            <span>{ad.cta}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            onClick={() => setClosed(true)}
            className="p-1.5 rounded-full text-rose-300/50 hover:text-white"
            title="Dismiss ad"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // Top or In-story luxury banner
  return (
    <div className="my-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="rounded-2xl p-3 sm:p-4 bg-[#140b1c] border border-rose-900/40 flex items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-rose-600/20 text-rose-300 uppercase">
            Sponsored Ad
          </span>
          <p className="text-rose-100/80 truncate font-serif">
            <strong className="text-white font-bold">{ad.title}:</strong> {ad.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <a
            href={ad.link}
            onClick={(e) => {
              e.preventDefault();
              alert(`Navigating to: ${ad.title}`);
            }}
            className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold whitespace-nowrap"
          >
            {ad.cta}
          </a>
          <button onClick={() => setClosed(true)} className="text-rose-200/50 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
