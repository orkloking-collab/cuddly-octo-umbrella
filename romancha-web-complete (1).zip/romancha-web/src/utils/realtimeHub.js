// Real-Time Cross-Client & Multi-Device Sync Hub (Stories, Reels, Chat, Feedbacks, Profile Updates, Gifts)
class RealtimeChatHub {
  constructor() {
    this.eventSource = null;
    this.broadcastChannel = null;
    this.messageListeners = new Set();
    this.storyListeners = new Set();
    this.reelListeners = new Set();
    this.feedbackListeners = new Set();
    this.profileListeners = new Set();
    this.giftListeners = new Set();
    this.presenceListeners = new Set();
    this.isConnected = false;
    this.currentUser = null;
    this.pingInterval = null;

    this.initBroadcastChannel();
    this.connectSSE();
  }

  initBroadcastChannel() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.broadcastChannel = new BroadcastChannel('romancha_realtime_sync_v2');
        this.broadcastChannel.onmessage = (event) => {
          if (!event.data) return;
          const { type, payload } = event.data;
          if (type === 'message') this.notifyMessage(payload);
          if (type === 'story') this.notifyStory(payload);
          if (type === 'reel') this.notifyReel(payload);
          if (type === 'feedback') this.notifyFeedback(payload);
          if (type === 'profile_update') this.notifyProfile(payload);
          if (type === 'gift') this.notifyGift(payload);
          if (type === 'presence') this.notifyPresence(payload);
        };
      } catch (e) {
        console.warn('BroadcastChannel fallback', e);
      }
    }
  }

  connectSSE() {
    if (typeof window === 'undefined') return;

    try {
      if (this.eventSource) {
        try { this.eventSource.close(); } catch(e){}
      }

      this.eventSource = new EventSource('/api/realtime/stream');

      this.eventSource.onopen = () => {
        this.isConnected = true;
      };

      this.eventSource.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload.type === 'message') {
            this.notifyMessage(payload.message);
          } else if (payload.type === 'story') {
            this.notifyStory(payload.story);
          } else if (payload.type === 'reel') {
            this.notifyReel(payload.reel);
          } else if (payload.type === 'profile_update') {
            this.notifyProfile(payload.profile);
          } else if (payload.type === 'feedback') {
            this.notifyFeedback(payload.feedback);
          } else if (payload.type === 'gift') {
            this.notifyGift(payload.gift);
          } else if (payload.type === 'history') {
            if (payload.messages) payload.messages.forEach(m => this.notifyMessage(m, true));
            if (payload.stories) payload.stories.forEach(s => this.notifyStory(s, true));
            if (payload.reels) payload.reels.forEach(r => this.notifyReel(r, true));
            if (payload.userProfiles) payload.userProfiles.forEach(p => this.notifyProfile(p, true));
            if (payload.feedbacks) payload.feedbacks.forEach(f => this.notifyFeedback(f, true));
            if (payload.onlineMembers) this.notifyPresence(payload.onlineMembers);
          } else if (payload.type === 'presence') {
            this.notifyPresence(payload.onlineMembers);
          }
        } catch (e) {
          console.error('Error parsing SSE event', e);
        }
      };

      this.eventSource.onerror = () => {
        this.isConnected = false;
        if (this.eventSource) {
          try { this.eventSource.close(); } catch(e){}
        }
        setTimeout(() => this.connectSSE(), 4000);
      };
    } catch (e) {
      console.warn('SSE connection error', e);
    }
  }

  setUser(user) {
    this.currentUser = user;
    this.sendPresence();

    if (!this.pingInterval) {
      this.pingInterval = setInterval(() => this.sendPresence(), 15000);
    }
  }

  async sendPresence() {
    if (!this.currentUser) return;
    try {
      await fetch('/api/realtime/presence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(this.currentUser)
      });
    } catch (e) {
      // ignore
    }
  }

  // Publish generic real-time events (Story, Reel, Feedback, Message, Profile, Gift)
  async publish(type, data) {
    try {
      const res = await fetch('/api/realtime/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, [type]: data, ...data })
      });
      const resData = await res.json();
      
      // Local tab broadcast
      if (this.broadcastChannel) {
        this.broadcastChannel.postMessage({ type, payload: data });
      }

      return resData;
    } catch (e) {
      console.error('Failed to publish realtime event', e);
      if (this.broadcastChannel) {
        this.broadcastChannel.postMessage({ type, payload: data });
      }
    }
  }

  async sendMessage(msgPayload) {
    this.notifyMessage(msgPayload);
    return this.publish('message', msgPayload);
  }

  async publishStory(story) {
    this.notifyStory(story);
    return this.publish('story', story);
  }

  async publishReel(reel) {
    this.notifyReel(reel);
    return this.publish('reel', reel);
  }

  async publishProfileUpdate(profile) {
    this.notifyProfile(profile);
    return this.publish('profile_update', profile);
  }

  async publishFeedback(feedback) {
    this.notifyFeedback(feedback);
    return this.publish('feedback', feedback);
  }

  async sendGift(gift) {
    this.notifyGift(gift);
    return this.publish('gift', gift);
  }

  onMessage(cb) { this.messageListeners.add(cb); return () => this.messageListeners.delete(cb); }
  onStory(cb) { this.storyListeners.add(cb); return () => this.storyListeners.delete(cb); }
  onReel(cb) { this.reelListeners.add(cb); return () => this.reelListeners.delete(cb); }
  onProfile(cb) { this.profileListeners.add(cb); return () => this.profileListeners.delete(cb); }
  onFeedback(cb) { this.feedbackListeners.add(cb); return () => this.feedbackListeners.delete(cb); }
  onGift(cb) { this.giftListeners.add(cb); return () => this.giftListeners.delete(cb); }
  onPresence(cb) { this.presenceListeners.add(cb); return () => this.presenceListeners.delete(cb); }

  subscribeMessages(cb) { return this.onMessage(cb); }
  subscribeStories(cb) { return this.onStory(cb); }
  subscribeReels(cb) { return this.onReel(cb); }
  subscribeProfileUpdates(cb) { return this.onProfile(cb); }
  subscribeFeedbacks(cb) { return this.onFeedback(cb); }
  subscribeGifts(cb) { return this.onGift(cb); }
  subscribePresence(cb) { return this.onPresence(cb); }

  notifyMessage(msg, isHist) { this.messageListeners.forEach(cb => { try { cb(msg, isHist); } catch(e){} }); }
  notifyStory(story, isHist) { this.storyListeners.forEach(cb => { try { cb(story, isHist); } catch(e){} }); }
  notifyReel(reel, isHist) { this.reelListeners.forEach(cb => { try { cb(reel, isHist); } catch(e){} }); }
  notifyProfile(profile, isHist) { this.profileListeners.forEach(cb => { try { cb(profile, isHist); } catch(e){} }); }
  notifyFeedback(fb, isHist) { this.feedbackListeners.forEach(cb => { try { cb(fb, isHist); } catch(e){} }); }
  notifyGift(gift, isHist) { this.giftListeners.forEach(cb => { try { cb(gift, isHist); } catch(e){} }); }
  notifyPresence(m) { this.presenceListeners.forEach(cb => { try { cb(m); } catch(e){} }); }
}

export const realtimeHub = new RealtimeChatHub();
